zip -r ../gngeo_data.zip *
